## Tested with
- Python 3.8
- Ubuntu 20.04

## Installing required packages
`pip3 install -r requirements.txt`

## Executing the default environment
`python3 main.py`